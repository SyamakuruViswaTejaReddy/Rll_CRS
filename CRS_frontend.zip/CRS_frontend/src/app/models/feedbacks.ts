export class Feedbacks {
  feedbackId: number;
  ticketId: number;
  customerEmail: string;
  feedback: string = '';
}

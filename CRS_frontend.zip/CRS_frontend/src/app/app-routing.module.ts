import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminComponent } from './components/admin/admin.component';
import { CustomersComponent } from './components/customers/customers.component';
import { EngineersComponent } from './components/engineers/engineers.component';
import { ManagersComponent } from './components/managers/managers.component';

const routes: Routes = [
  {path:"admin",component:AdminComponent},
  {path:"customers",component:CustomersComponent},
  {path:"managers",component:ManagersComponent},
  {path:"engineers",component:EngineersComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
